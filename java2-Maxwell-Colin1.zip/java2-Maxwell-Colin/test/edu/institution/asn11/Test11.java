/* Colin Maxwell
 * Java II
 * Binary Search Tree
 * 4/18/2021
 */
package edu.institution.asn11;

import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;


public class Test11 {

	
	@Test
	public void testBST() {
		
		/*Breadth First Traversal with Integer*/
		BST<Integer> binaryInt = new BST<Integer>();
		/*Test Null*/
		Assert.assertNull(binaryInt.breadthFirstTraversal());
		binaryInt.insert(60);
		binaryInt.insert(55);
		binaryInt.insert(45);
		binaryInt.insert(57);
		binaryInt.insert(100);
		binaryInt.insert(67);
		binaryInt.insert(107);
		List<Integer> intList = binaryInt.breadthFirstTraversal();
	//	System.out.println(intList);
		
		/*Test first and last index*/
		Assert.assertEquals(60, intList.get(0).intValue());
		Assert.assertEquals(107, intList.get(intList.size() -  1).intValue());
		/*Test Height*/
		Assert.assertEquals(2, binaryInt.getHeight());
		binaryInt.insert(110);
		binaryInt.insert(112);
		/*Test New Height*/
		binaryInt.breadthFirstTraversal();
		Assert.assertEquals(4, binaryInt.getHeight());

		// -----------------------------
		
		/*Breadth First Traversal with String*/
		BST<String> binaryString = new BST<String>();
		/*Test Null*/
		Assert.assertNull(binaryString.breadthFirstTraversal());
		binaryString.insert("George");
		binaryString.insert("Adam");
		binaryString.insert("Daniel");
		binaryString.insert("Michael");
		binaryString.insert("Jones");
		binaryString.insert("Tom");
		binaryString.insert("Peter");
		List<String> stringList = binaryString.breadthFirstTraversal();
	//	System.out.println(stringList);
		
		/*Test first and Last Index*/
		Assert.assertEquals("George", stringList.get(0));
		Assert.assertEquals("Peter", stringList.get(stringList.size() -  1));
		/*Test Height*/
		Assert.assertEquals(3, binaryString.getHeight());
	//	System.out.println("String height " + binaryString.getHeight());
		binaryString.insert("Trevor");
		binaryString.insert("Zeke");
		/*Test New Height*/
		binaryString.breadthFirstTraversal();
		Assert.assertEquals(4, binaryString.getHeight());
		
		/*---------------------------------------------*/ 
		
		/*Non-Recursive Traversal with Integer*/
		 BST<Integer> inOrderInt = new BST<Integer>();
		 /*Test Null*/
		 Assert.assertNull(inOrderInt.nonRecursiveInorder());
		 inOrderInt.insert(60);
		 inOrderInt.insert(55);
		 inOrderInt.insert(45);
		 inOrderInt.insert(57);
		 inOrderInt.insert(100);
		 inOrderInt.insert(67);
		 inOrderInt.insert(107);
		 List<Integer> inOrderIntList = inOrderInt.nonRecursiveInorder();
	//	 System.out.println(inOrderIntList);
		 
		 /*Test first and Last Index*/
		 Assert.assertEquals(45, inOrderIntList.get(0).intValue());
		 Assert.assertEquals(107, inOrderIntList.get(inOrderIntList.size() - 1).intValue());
		 /*Test Height*/
		 Assert.assertEquals(2, inOrderInt.getHeight());
		 inOrderInt.insert(110);
		 inOrderInt.insert(112);
		 /*Test New Height*/
		 inOrderInt.nonRecursiveInorder();
		 Assert.assertEquals(4, inOrderInt.getHeight());
		 
		 // --------------------------------------------
		 
		 BST<String> inOrderString = new BST<String>();
		 /*Test Null*/
		 Assert.assertNull(inOrderString.nonRecursiveInorder());
		 inOrderString.insert("George");
		 inOrderString.insert("Adam");
		 inOrderString.insert("Daniel");
		 inOrderString.insert("Michael");
		 inOrderString.insert("Jones");
		 inOrderString.insert("Tom");
		 inOrderString.insert("Peter");
		 List<String> inOrderStringList = inOrderString.nonRecursiveInorder();
	//	 System.out.println(inOrderStringList);
		 
		 /*Test First and Last Index*/
		 Assert.assertEquals("Adam", inOrderStringList.get(0));
		 Assert.assertEquals("Tom", inOrderStringList.get(inOrderStringList.size() - 1));
		 /*Test Height*/
		 Assert.assertEquals(3, inOrderString.getHeight());
		 inOrderString.insert("Trevor");
		 inOrderString.insert("Zeke");
		 /*Test New Height*/
		 inOrderString.nonRecursiveInorder();
		 Assert.assertEquals(4, inOrderString.getHeight());
		 
		
	} // End Test()
	
	
} // End Class
