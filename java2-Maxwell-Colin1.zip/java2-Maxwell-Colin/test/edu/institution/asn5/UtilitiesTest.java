/* Colin Maxwell
 * Java II Assignment 5 - Utility Methods
 * 2/21/21
 */

package edu.institution.asn5;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;


import edu.institution.actions.asn5.Utilities;
import edu.institution.asn2.LinkedInUser;


public class UtilitiesTest {

	
	@Test
	public void testDuplicates() {
 		/*String Test*/
		List<String> newList = new ArrayList<>();

		newList.add("Colin");
		newList.add("Colin"); 
		newList.add("Colin");
		newList.add("Ken");
		newList.add("Ken");
		
		Utilities obj = new Utilities();
		obj.removeDuplicates(newList);
		
		Assert.assertTrue(newList.size() == 2);
		
		/*Integer Test*/
		List<Integer> newList2 = new ArrayList<>();
		
		newList2.add(1);
		newList2.add(1);
		
		obj.removeDuplicates(newList2);
				
		Assert.assertTrue(newList2.size() ==1);
		
		/*LinkedInUser Test*/
		List<LinkedInUser> newList3 = new ArrayList<>();
		
		LinkedInUser han = new LinkedInUser("han", "falcon");
		LinkedInUser luke = new LinkedInUser("luke", "force");
		LinkedInUser leia = new LinkedInUser("leia", "x");
		LinkedInUser chewy = new LinkedInUser("han", "h");
		LinkedInUser lando = new LinkedInUser(null, null); //Test Null

		List<Integer> newList4 = new ArrayList<>();
		
		obj.removeDuplicates(newList4); //Returns blank list
		
		System.out.println(newList4);
		newList3.add(han);
		newList3.add(luke);
		newList3.add(leia);
		newList3.add(chewy);
		newList3.add(lando);
		
		obj.removeDuplicates(newList3);
		obj.removeDuplicates(null);
		
		Assert.assertTrue(newList3.size() ==4);

		//System.out.println(newList3);
		
	} // End testDuplicates()
	
	
	
	@Test
	public void testLinear() {
		/*Test LinkedInUser*/
		List<LinkedInUser> users = new ArrayList<>();
		
		
		LinkedInUser han = new LinkedInUser("han", "falcon");
		LinkedInUser luke = new LinkedInUser("luke", "force");
		LinkedInUser leia = new LinkedInUser("leia", "x");
		LinkedInUser vader = new LinkedInUser("Vader" , null); 
		
		users.add(null);
		users.add(leia);
		users.add(luke);
		users.add(han);
		
		Utilities obj = new Utilities();
		
		//Testing LinkedInUser
		Assert.assertEquals(han, obj.linearSearch(users, han));
		
		Assert.assertNull(obj.linearSearch(users, vader));
		
		List<LinkedInUser> usersNull = new ArrayList<>();
		//Testing Null
		Assert.assertNull(obj.linearSearch(usersNull, null));
		Assert.assertNull(obj.linearSearch(null, null));
	
		
		/*Test Integer*/
		List<Integer> users2 = new ArrayList<>();
		
		users2.add(1);
		users2.add(2);
		users2.add(3);
		users2.add(0);
		users2.add(null); 
		
		Integer num = 2;
		Assert.assertEquals(num, obj.linearSearch(users2, num));
		
		
		/*Test String*/
		List<String> strings = new ArrayList<>();
		strings.add("Watermelon");
		strings.add("Apple");
		strings.add("Pear");
		strings.add("Peaches");
		Assert.assertEquals("Pear", obj.linearSearch(strings, "Pear"));
		
		
		
		
	}
	
	
} //End Class
