package edu.institution.asn9;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class SortingTest {

	private static String PATH = System.getProperty("user.home") + File.separator + "Java2" + File.separator;
	private static String FILE_NAME = "asn9-numbers.txt";
		
	@Test
	public void testSorting() {
		
		SortAlgorithmMetrics sort = new SortAlgorithmMetrics();
		
		//Tests for Null File
		List<MetricData> newList2 = sort.retrieveMetrics("Colin");
		Assert.assertNull(newList2);
		
		newList2 = sort.retrieveMetrics(PATH + FILE_NAME);

		//Test Size
		Assert.assertEquals(5, newList2.size());
		
		//Tests if newList2 contains each Sorting Algorithm
		for(MetricData md: newList2)
		{
			if(md.getSortAlgorithm().equals(SortAlgorithm.BUBBLE_SORT))
			{
				Assert.assertEquals(SortAlgorithm.BUBBLE_SORT, md.getSortAlgorithm());
				Assert.assertEquals(TimeComplexity.QUADRATIC, md.getTimeComplexity());
			}
			else if (md.getSortAlgorithm().equals(SortAlgorithm.QUICK_SORT))
			{
				Assert.assertEquals(SortAlgorithm.QUICK_SORT, md.getSortAlgorithm());
				Assert.assertEquals(TimeComplexity.QUADRATIC, md.getTimeComplexity());
			}
			else if (md.getSortAlgorithm().equals(SortAlgorithm.MERGE_SORT))
			{
				Assert.assertEquals(SortAlgorithm.MERGE_SORT, md.getSortAlgorithm());
				Assert.assertEquals(TimeComplexity.LOGARITHMIC, md.getTimeComplexity());
			}
			else if (md.getSortAlgorithm().equals(SortAlgorithm.INSERTION_SORT))
			{
				Assert.assertEquals(SortAlgorithm.INSERTION_SORT, md.getSortAlgorithm());
				Assert.assertEquals(TimeComplexity.QUADRATIC, md.getTimeComplexity());
			}
			else if (md.getSortAlgorithm().equals(SortAlgorithm.HEAP_SORT)){
				Assert.assertEquals(SortAlgorithm.HEAP_SORT, md.getSortAlgorithm());
				Assert.assertEquals(TimeComplexity.LOGARITHMIC, md.getTimeComplexity());
			}
				
			else {
				System.out.println("Unknown Sorting Algorithm");
			}

		} 
		

		/*Test Execution Time
		Assert.assertEquals(32l, newList2.get(0).getExecutionTime(), 30.0);
		Assert.assertEquals(45l, newList2.get(1).getExecutionTime(), 30.0);
		Assert.assertEquals(55l, newList2.get(2).getExecutionTime(), 30.0);
		Assert.assertEquals(3000l, newList2.get(3).getExecutionTime(), 400.0);
		Assert.assertEquals(20000l, newList2.get(4).getExecutionTime(), 1000.0);
		*/
		
		for(MetricData md : newList2)
		{
			
			System.out.println(md.toString());
		}
		
	} //End testSorting()
	
	
	@Test
	public void testMetricData() {
		
		
		/*Bubble Sort*/
		MetricData mc1 = new MetricData(SortAlgorithm.BUBBLE_SORT); // Set Algorithm = Bubble Sort
		Assert.assertEquals(SortAlgorithm.BUBBLE_SORT, mc1.getSortAlgorithm());
		Assert.assertEquals("Bubble Sort", mc1.getSortAlgorithm().display());
		//Test TimeComplexity
		mc1.setTimeComplexity(TimeComplexity.QUADRATIC);
		Assert.assertEquals(TimeComplexity.QUADRATIC, mc1.getTimeComplexity());
		Assert.assertEquals("Quadratic O(n2)", mc1.getTimeComplexity().display());
		//Test ExecutionTime
		Integer[] arrayBubbleInt = {2,8,3,4,9,5,7,1};
		//Time Bubble Sort
		LocalTime start1 = LocalTime.now();
		BubbleSort.bubbleSort(arrayBubbleInt);
		LocalTime end1 = LocalTime.now();
		//Set Execution Time
		long time1 = Duration.between(start1, end1).toMillis();
		mc1.setExecutionTime(time1);
		Assert.assertEquals(time1, mc1.getExecutionTime());
		
		// ---------------------
		
		/*Merge Sort*/
		//Test SortAlgorithm
		MetricData mc2 = new MetricData(SortAlgorithm.MERGE_SORT); //Set Algorithm = Merge Sort
		Assert.assertEquals(SortAlgorithm.MERGE_SORT, mc2.getSortAlgorithm());
		Assert.assertEquals("Merge Sort", mc2.getSortAlgorithm().display());
		//Test TimeComplexity
		mc2.setTimeComplexity(TimeComplexity.LOGARITHMIC);
		Assert.assertEquals(TimeComplexity.LOGARITHMIC, mc2.getTimeComplexity());
		Assert.assertEquals("Logarithmic O(n log n)", mc2.getTimeComplexity().display());
		//Test ExecutionTime
		Integer[] arrayMergeInt = {2,8,3,4,9,5,7,1};
		//Time Merge Sort
		LocalTime start2 = LocalTime.now();
	    MergeSort.mergeSort(arrayMergeInt);
		LocalTime end2 = LocalTime.now();
		// Set Execution Time
		long time2 = Duration.between(start2, end2).toMillis();
		mc2.setExecutionTime(time2);
		Assert.assertEquals(time2, mc2.getExecutionTime());
		
		// ---------------------
		
		/*Quick Sort*/
		MetricData mc3 = new MetricData(SortAlgorithm.QUICK_SORT); //Set Algorithm = Quick Sort
		Assert.assertEquals(SortAlgorithm.QUICK_SORT, mc3.getSortAlgorithm());
		Assert.assertEquals("Quick Sort", mc3.getSortAlgorithm().display());
		//Test TimeComplexity
		mc3.setTimeComplexity(TimeComplexity.QUADRATIC);
		Assert.assertEquals(TimeComplexity.QUADRATIC, mc3.getTimeComplexity());
		Assert.assertEquals("Quadratic O(n2)", mc3.getTimeComplexity().display());
		//Test Execution Time
		Integer[] arrayQuickInt = {2,8,3,4,9,5,7,1};
		//Time Quick Sort
		LocalTime start3 = LocalTime.now();
		QuickSort.quickSort(arrayQuickInt);
		LocalTime end3 = LocalTime.now();
		// Set Execution Time
		long time3 = Duration.between(start3, end3).toMillis();
		mc3.setExecutionTime(time3);
		Assert.assertEquals(time3, mc3.getExecutionTime());
		
		// ---------------------------
		
		/*Heap Sort*/
		MetricData mc4 = new MetricData(SortAlgorithm.HEAP_SORT); //Set Algorithm = Heap Sort
		Assert.assertEquals(SortAlgorithm.HEAP_SORT, mc4.getSortAlgorithm());
		Assert.assertEquals("Heap Sort", mc4.getSortAlgorithm().display());
		//Test TimeComplexity
		mc4.setTimeComplexity(TimeComplexity.LOGARITHMIC);
		Assert.assertEquals(TimeComplexity.LOGARITHMIC, mc4.getTimeComplexity());
		Assert.assertEquals("Logarithmic O(n log n)", mc4.getTimeComplexity().display());
		//Test Execution Time
		Integer[] arrayHeapInt = {2,8,3,4,9,5,7,1};
		//Time Heap Sort
		LocalTime start4 = LocalTime.now();
		HeapSort.heapSort(arrayHeapInt);
		LocalTime end4 = LocalTime.now();
		// Set Execution Time
		long time4 = Duration.between(start4, end4).toMillis();
		mc4.setExecutionTime(time4);
		
		
		
		Assert.assertEquals(time4, mc4.getExecutionTime());
		
		//-----------------------------------
		
		/*Insertion Sort*/
		MetricData mc5 = new MetricData(SortAlgorithm.INSERTION_SORT); //Set Algorithm = Insertion Sort
		Assert.assertEquals(SortAlgorithm.INSERTION_SORT, mc5.getSortAlgorithm());
		Assert.assertEquals("Insertion Sort", mc5.getSortAlgorithm().display());
		//Test Time Complexity
		mc5.setTimeComplexity(TimeComplexity.QUADRATIC);
		Assert.assertEquals(TimeComplexity.QUADRATIC, mc5.getTimeComplexity());
		Assert.assertEquals("Quadratic O(n2)", mc5.getTimeComplexity().display());
		//Test Execution Time
		Integer[] arrayInsertionInt = {2,8,3,4,9,5,7,1};
		//Time Insertion Sort
		LocalTime start5 = LocalTime.now();
		InsertionSort.insertionSort(arrayInsertionInt);
		LocalTime end5 = LocalTime.now();
		// Set Execution TIme
		long time5 = Duration.between(start5, end5).toMillis();
		mc5.setExecutionTime(time5);
		Assert.assertEquals(time5, mc5.getExecutionTime());
		
		
		
	}
	
	
	
	
	
	
} //End Class
