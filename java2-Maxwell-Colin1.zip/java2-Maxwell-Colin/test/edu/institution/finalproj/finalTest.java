/* Colin Maxwell
 * Java II
 * Final Project
 * 5/3/2021
 */

package edu.institution.finalproj;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import edu.institution.finalproj.AnagramDataReaderImpl;
import org.junit.Assert;

public class finalTest {
	
	@Test
	public void TestImportNames() {
		
		AnagramEvaluatorImpl anagramEvaluate = new AnagramEvaluatorImpl();
		AnagramDataReaderImpl anagramDataRead = new AnagramDataReaderImpl();
		
		List<String> permList = new ArrayList<String>();

		//Test file Import
		Assert.assertEquals(373295, anagramDataRead.readData().size());
		
		/*---Test no-filter--- */
		//Test size of no-filtered list
		permList = anagramEvaluate.evaluate("dog", "nf");
		Assert.assertEquals(6, permList.size());
		//Test if permutationsList is in alphabetical order
		Assert.assertEquals("dgo", permList.get(0)); //First index
		Assert.assertEquals("ogd", permList.get(permList.size() - 1)); //Last index
		
		permList = anagramEvaluate.evaluate("dog", "words");
		
		/*---Test words---*/
		//Test size of word-filtered list
		Assert.assertEquals(2, permList.size());
		
		//Tset if wordList is in alphabetical order
		Assert.assertEquals("dog", permList.get(0)); //First index
		Assert.assertEquals("god", permList.get(permList.size() -1)); //Last index
		
		/*---Test List for no words---*/
		permList = anagramEvaluate.evaluate("gxzy", "words"); 
		Assert.assertTrue(permList.isEmpty());
		
		/*---Test for Null list---*/
		Assert.assertNull(anagramEvaluate.evaluate(null, "ColinMaxwell"));
		
		Assert.assertNull(anagramEvaluate.evaluate("dog", ""));

	}

	@Test
	public void testMore() {
		AnagramDataReaderImpl anagramDataRead = new AnagramDataReaderImpl();

		//Test for no filepath
		anagramDataRead.namesFile = "";
		Assert.assertEquals(0, anagramDataRead.readData().size());
	}
	
	
	
} //End Class
