/* 
 * Colin Maxwell
 * Java 2
 * Midterm 
 * 3/7/2021
 * 
 */


package edu.institution.midterm;

import java.io.File;

import org.junit.Test;
import edu.institution.midterm.PartManagerImpl;
import org.junit.Assert;

public class midtermTest {

	private static String PATH = System.getProperty("user.home") + File.separator + "Java2" + File.separator;
	private static String FILE_NAME = "bom.json";

	@Test
	public void Test1Import() {
	
		PartManagerImpl newPartTest = new PartManagerImpl();	
		//Test import part store 
		Assert.assertEquals(79, newPartTest.importPartStore(PATH + FILE_NAME));
		Assert.assertEquals(0, newPartTest.importPartStore("")); //Test for bad file name
	
		Part testPart = new Part();
		
		//Test retirevePart 
		testPart = newPartTest.retrievePart("290B7266J1");
		Assert.assertEquals("290B7266J1", testPart.getPartNumber());
		//Test Null
		Assert.assertNull(newPartTest.retrievePart("290442534")); 
		
		Assert.assertEquals(52, newPartTest.getPurchasePartsByPrice().size()); //Tests list size for getPurchasePartsByPrice Method
		Assert.assertEquals(4, newPartTest.getFinalAssemblies().size()); //Tests list size for getFinalAssemblies Method
		
		// https://stackoverflow.com/questions/7554281/junit-assertions-make-the-assertion-between-floats
		//Looked up how to Junit test for floats
		/*Tests Sample Data*/
		Assert.assertEquals(334.1f, newPartTest.costPart("290B7266J6").getPrice(), 0.0);
		Assert.assertEquals(415.16f, newPartTest.costPart("290B7266J1").getPrice(), 0.0); 
		Assert.assertEquals(532.20f, newPartTest.costPart("290B7266J2").getPrice(), 0.0);
		Assert.assertEquals(96.39f, newPartTest.costPart("20-0001").getPrice(), 0.0);
		Assert.assertEquals(70.46f, newPartTest.costPart("20-0015").getPrice(), 0.0);		
		
	}// End Test1
	
} //End Class
